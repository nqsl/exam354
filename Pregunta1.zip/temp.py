# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

lista1 = [1,2,3,4,5]
print(lista1)
print(lista1[0])
print(lista1[:2])
print(lista1[2:])

for i in lista1:
    print(i)
    
for i in range(10):
    print(i)
    
for i in range(10,20,2):
    print(i)
lista2 = [i for i in range(5,15,3)]
print(lista2)

print(sum(lista1))

a=5 
b=6
print(sum([b for i in range(a)]))
 
def suma(a,b):
     return a+b
 
print(suma(5,6))

def multi(a,b):
    return sum([b for i in range(a)])

print(multi(5,6))

lista3="hola"
print(lista3[3])
print(lista3[:3])
print(lista3[3:])

import numpy as np 

array21 = np.asarray(lista2)
array22 = np.array(lista2) 
print(lista2)
print(array21)
print(array22)

array23 = np.array([1,2,3,4,5,6])
array24 = np.resize(array23,(2,3))
print(array24)

print(np.sum(array24))
print(np.sum(array24, axis=None))
print(np.sum(array24, axis=0))
print(np.sum(array24, axis=1))

print(np.mean(array24))
print(np.mean(array24, axis=None))
print(np.mean(array24, axis=0))
print(np.mean(array24, axis=1))

print(np.median(array24))
print(np.median(array24, axis=None))
print(np.median(array24, axis=0))
print(np.median(array24, axis=1))

print(np.std(array24))
print(np.std(array24, axis=None))
print(np.std(array24, axis=0))
print(np.std(array24, axis=1))

print(array23)
print(np.percentile(array23, 0))
print(np.percentile(array23, 50))

import pandas as pd 
datos = pd.read_csv("datasus_suicidio_2014_2018.csv")
print(datos)
 
datasus_suicidio_2014_2018 = pd.read_csv("datasus_suicidio_2014_2018.csv", sep="-")
print(datasus_suicidio_2014_2018)
print(datasus_suicidio_2014_2018.head)
print(datasus_suicidio_2014_2018["sepallenght"])

print(np.sum(datasus_suicidio_2014_2018["sepallenght"]))
print(np.median(datasus_suicidio_2014_2018["sepallenght"]))

print(datasus_suicidio_2014_2018.loc[datasus_suicidio_2014_2018["sepalwidht"]==3.5].sum())

datasus_suicidio_2014_2018columna=datasus_suicidio_2014_2018["sepallenth"]
print(datasus_suicidio_2014_2018columna.loc[datasus_suicidio_2014_2018columna==4.9].sum())
